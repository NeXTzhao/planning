#pragma once

#include <string>
#include <vector>

struct LinePoint {
  double s;
  double x;
  double y;
  double theta;
  double kappa;
};

struct InitStatus {
  double start_x_ = 0.0;
  double start_y_ = 0.0;
  double start_yaw_ = 0.0;
  double resolution_ = 0.1;
};

class LaneLine {
 public:
  explicit LaneLine(const std::vector<std::vector<double>> &config);

  std::vector<LinePoint> getCenterLinePoints() const { return center_line_points_; }
  std::vector<LinePoint> getLeftBoundPoints() const { return left_bound_points_; }
  std::vector<LinePoint> getRightBoundP0ints() const { return right_bound_points_; }

 private:
  void
  generateCenterLineAndBounds(double left_bound_offset = -3.5, double right_bound_offset = 3.5);

  static void writeJsonToFile(const std::vector<LinePoint> &points,
                              const std::vector<LinePoint> &left_bound_points,
                              const std::vector<LinePoint> &right_bound_points,
                              const std::string &filename);

 private:
  std::vector<std::vector<double>> config_;
  InitStatus init_status_;
  std::vector<LinePoint> points;
  std::vector<LinePoint> center_line_points_;
  std::vector<LinePoint> left_bound_points_;
  std::vector<LinePoint> right_bound_points_;
};
