use std::f64::consts::PI;
use optimization_engine::{alm::*, constraints::*, panoc::*, core::*};
use csv;
use indexing;

mod fcn;

// ---Private Constants----
/// Tolerance of inner solver
const EPSILON_TOLERANCE: f64 = 1e-3;

/// LBFGS memory
const LBFGS_MEMORY: usize = 350;


/// Solver interface
pub unsafe fn open_solve(thetas: &[f64], kappas: &[f64], xs: &[f64], ys: &[f64], deltas: &[f64], solution: &mut [f64], size: usize) {
    let nx = 5 * size - 1;
    let n1 = 0;
    let n2 = size - 1;

    // initial value
    let mut u = vec![0.0; nx];
    let delta_start = size * 4;
    for i in 0..size {
        let index = 4 * i;
        u[index + 0] = thetas[i];
        u[index + 1] = kappas[i];
        u[index + 2] = xs[i];
        u[index + 3] = ys[i];
    }
    for i in 0..size - 1 {
        u[delta_start + i] = deltas[i];
    }

    // cost function
    let cost_function = |u: &[f64], cost: &mut f64| -> Result<(), SolverError>{
        *cost = fcn::cost_function(u, size);
        Ok(())
    };

    // cost function grad
    let cost_function_grad = |u: &[f64], res: &mut [f64]| -> Result<(), crate::SolverError>{
        fcn::cost_function_grad(u, size, res);
        Ok(())
    };

    fcn::EX_VEC.resize(size - 1, 0.0);
    fcn::EY_VEC.resize(size - 1, 0.0);

    // constrain function
    let constrain_function = |u: &[f64], res: &mut [f64]| -> Result<(), SolverError> {
        fcn::constrain_function(&u, res, size);
        Ok(())
    };

    // constrain function grad
    let constrain_function_grad = |u: &[f64], d: &[f64], grad: &mut [f64]| -> Result<(), SolverError> {
        fcn::constrain_function_grad(u, d, size, grad);
        Ok(())
    };

    // get bounds info
    let mut lower_bound = vec![-f64::INFINITY; nx];
    let mut upper_bound = vec![f64::INFINITY; nx];
    // let delta_index = size * 4;
    let fault_dis = 0.1;
    /* for theta kappa x y */
    for i in 0..size {
        let index = i * 4;
        // x
        lower_bound[index + 2] = u[index + 2] - fault_dis;
        upper_bound[index + 2] = u[index + 2] + fault_dis;
        // y
        lower_bound[index + 3] = u[index + 3] - fault_dis;
        upper_bound[index + 3] = u[index + 3] + fault_dis;
    }


    let panoc_cache = PANOCCache::new(nx, EPSILON_TOLERANCE, LBFGS_MEMORY);
    let mut alm_cache = AlmCache::new(panoc_cache, n1, n2);

    let bounds = Rectangle::new(Some(lower_bound.as_slice()), Some(&upper_bound.as_slice()));

    let factory = AlmFactory::new(
        cost_function,
        cost_function_grad,
        NO_MAPPING,
        NO_JACOBIAN_MAPPING,
        Some(constrain_function),
        Some(constrain_function_grad),
        NO_SET,
        n2,
    );

    let alm_problem = AlmProblem::new(
        bounds,
        NO_SET,
        NO_SET,
        |u: &[f64], xi: &[f64], cost: &mut f64| -> Result<(), SolverError> {
            factory.psi(u, xi, cost)
        },
        |u: &[f64], xi: &[f64], grad: &mut [f64]| -> Result<(), SolverError> {
            factory.d_psi(u, xi, grad)
        },
        NO_MAPPING,
        Some(constrain_function),
        n1,
        n2,
    );

    // Construct an optimiser and configure it
    let mut alm_optimizer = AlmOptimizer::new(&mut alm_cache, alm_problem)
        .with_delta_tolerance(1e-2)
        .with_epsilon_tolerance(1e-2)
        .with_max_outer_iterations(20)
        .with_max_inner_iterations(1000)
        .with_initial_penalty(5000.0)
        .with_penalty_update_factor(2.2);

    // Solve the problem
    let solver_result = alm_optimizer.solve(&mut u);

    match solver_result {
        Ok(state) => {
            println!("Panoc status: {:#?}", state);
            for i in 0..size {
                solution[4 * i + 0] = u[4 * i + 0];
                solution[4 * i + 1] = u[4 * i + 1];
                solution[4 * i + 2] = u[4 * i + 2];
                solution[4 * i + 3] = u[4 * i + 3];
            }
            for i in 0..size - 1 {
                solution[delta_start + i] = u[delta_start + i];
            }
        }
        Err(error) => { panic!("Problem opening the file: {:?}", error) }
    }
}

fn main() -> std::io::Result<()> {
    let d_pi = 2.0 * PI;

    // read data from csv file
    let mut reader = csv::Reader::from_path("/home/pc/CLionProjects/rust_test/target/debug/path_points.csv")?;
    let _header = reader.headers()?;

    let mut raw_xs: Vec<f64> = Vec::new();
    let mut raw_ys: Vec<f64> = Vec::new();
    for result in reader.records() {
        let record = result?;
        raw_xs.push(record[0].parse().unwrap());
        raw_ys.push(record[1].parse().unwrap());
    }

    let mut raw_acc_s: Vec<f64> = Vec::new();
    raw_acc_s.push(0.0);
    for i in 0..raw_ys.len() {
        if i > 0 {
            let dx = raw_xs[i] - raw_xs[i - 1];
            let dy = raw_ys[i] - raw_ys[i - 1];
            let s = *raw_acc_s.last().unwrap();
            raw_acc_s.push(s + dx.hypot(dy));
        }
    }

    // down sample
    let mut xs: Vec<f64> = Vec::new();
    let mut ys: Vec<f64> = Vec::new();
    let mut deltas: Vec<f64> = Vec::new();

    let length = *raw_acc_s.last().unwrap();
    let length = length;
    let stride = 3.0;
    let mut p_idx = 0;
    for i in 0..(length / stride) as usize {
        let sample = i as f64 * stride;
        let idx = indexing::algorithms::lower_bound(raw_acc_s.as_slice(), &sample);
        if xs.len() > 0 {
            deltas.push(raw_acc_s[idx] - raw_acc_s[p_idx]);
        }
        p_idx = idx;
        xs.push(raw_xs[idx]);
        ys.push(raw_ys[idx]);
    }

    let mut thetas: Vec<f64> = Vec::with_capacity(xs.len());
    let mut kappas: Vec<f64> = Vec::with_capacity(xs.len());

    kappas.push(0.0);
    for (i, _val) in xs.iter().enumerate() {
        let x = xs[i];
        let y = ys[i];
        let mut xp: Option<f64> = None;
        let mut _yp: Option<f64> = None;
        let mut xn: Option<f64> = None;
        let mut yn: Option<f64> = None;
        if i + 1 < xs.len() {
            xn = Some(xs[i + 1]);
            yn = Some(ys[i + 1]);
        }
        if i > 0 {
            xp = Some(xs[i - 1]);
            _yp = Some(ys[i - 1]);
        }

        if let Some(_vn) = xn {
            let dx = xn.unwrap() - x;
            let dy = yn.unwrap() - y;
            let theta = dy.atan2(dx);
            thetas.push(theta);

            if let Some(_vp) = xp {
                let thetap = thetas[i - 1];
                let deltap = deltas[i - 1];
                let mut dtheta = theta - thetap;
                if dtheta < -PI {
                    dtheta += d_pi;
                }
                if dtheta > PI {
                    dtheta -= d_pi;
                }
                let kappa = dtheta / deltap;
                kappas.push(kappa);
            }
        }
    }

    let n = xs.len();
    if n > 1 {
        thetas.push(*thetas.last().unwrap());
        kappas.push(*kappas.last().unwrap());
    }
    if n > 2 {
        kappas[0] = kappas[1];
    }

    let mut theta_shift = 0.0;
    for i in 0..thetas.len() {
        thetas[i] += theta_shift;
        if i + 1 < thetas.len() {
            let theta = thetas[i];
            let theta_n = thetas[i + 1] + theta_shift;
            let d_theta = theta_n - theta;
            let da_theta = d_theta.abs();
            if f64::abs(theta_n - theta) > PI {
                if d_theta < 0.0 {
                    theta_shift += (da_theta / d_pi).round() * d_pi;
                } else {
                    theta_shift -= (da_theta / d_pi).round() * d_pi;
                }
            }
        }
    }

    // solve
    let mut solution: Vec<f64> = vec![0.0; 5 * n];
    unsafe {
        open_solve(&thetas, &kappas, &xs, &ys, &deltas, &mut solution, n);
    }

    // write to result file
    let mut writer = csv::Writer::from_path("/home/pc/CLionProjects/rust_test/target/debug/result.csv")?;
    for i in 0..n {
        let x = solution[4 * i + 2];
        let y = solution[4 * i + 3];
        let theta = solution[4 * i + 0];
        let kappa = solution[4 * i + 1];
        writer.write_record(&[x.to_string(), y.to_string(), theta.to_string(), kappa.to_string()])?;
    }
    writer.flush()?;

    Ok(())
}
