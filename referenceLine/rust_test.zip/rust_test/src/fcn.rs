// ---Private Mutable----
pub static mut EX_VEC: Vec<f64> = Vec::new();
pub static mut EY_VEC: Vec<f64> = Vec::new();

#[inline(always)]
#[allow(non_snake_case)]
fn Sin(x: f64) -> f64 {
    x.sin()
}

#[inline(always)]
#[allow(non_snake_case)]
fn Cos(x: f64) -> f64 {
    x.cos()
}

#[inline(always)]
#[allow(non_snake_case)]
fn Power(x: f64, i: i32) -> f64 {
    x.powi(i)
}

fn err_x(theta0: f64, kappa0: f64, x0: f64, _y0: f64, theta1: f64, kappa1: f64, x1: f64, _y1: f64, delta: f64) -> f64 {
    x0 - x1 + 0.11846344252809497 * delta * Cos(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.23931433524968299 * delta * Cos(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.28444444444444406 * delta * Cos(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.23931433524968299 * delta * Cos(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.11846344252809497 * delta * Cos(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn err_y(theta0: f64, kappa0: f64, _x0: f64, y0: f64, theta1: f64, kappa1: f64, _x1: f64, y1: f64, delta: f64) -> f64 {
    y0 - y1 + 0.11846344252809497 * delta * Sin(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.23931433524968299 * delta * Sin(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.28444444444444406 * delta * Sin(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.23931433524968299 * delta * Sin(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.11846344252809497 * delta * Sin(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ex_2_theta0(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    -0.11770584399014787 * delta * Sin(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) -
        0.20696377469486585 * delta * Sin(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) -
        0.14222222222222203 * delta * Sin(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) -
        0.03235056055481717 * delta * Sin(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) -
        0.0007575985379471051 * delta * Sin(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ex_2_kappa0(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    -0.0050479872655811485 * Power(delta, 2) * Sin(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) -
        0.03267811424642764 * Power(delta, 2) * Sin(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) -
        0.03555555555555551 * Power(delta, 2) * Sin(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) -
        0.009803219676551771 * Power(delta, 2) * Sin(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) -
        0.0002484565892171975 * Power(delta, 2) * Sin(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ex_2_x0(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    1.0
}

fn grad_ex_2_y0(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    0.0
}

fn grad_ex_2_theta1(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    -0.0007575985379471055 * delta * Sin(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) -
        0.03235056055481716 * delta * Sin(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) -
        0.14222222222222203 * delta * Sin(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) -
        0.20696377469486582 * delta * Sin(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) -
        0.11770584399014787 * delta * Sin(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ex_2_kappa1(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    0.000248456589217199 * Power(delta, 2) * Sin(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.009803219676551771 * Power(delta, 2) * Sin(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.03555555555555551 * Power(delta, 2) * Sin(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.03267811424642764 * Power(delta, 2) * Sin(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.005047987265581148 * Power(delta, 2) * Sin(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ex_2_x1(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    -1.0
}

fn grad_ex_2_y1(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    0.0
}

fn grad_ex_2_delta(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    0.11846344252809497 * Cos(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.23931433524968299 * Cos(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.28444444444444406 * Cos(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.23931433524968299 * Cos(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.11846344252809497 * Cos(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1) -
        0.11846344252809497 * delta * (0.04261219459652255 * kappa0 - 0.002097327107122306 * kappa1) *
            Sin(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) -
        0.23931433524968299 * delta * (0.13654892095090626 * kappa0 - 0.040963779567671166 * kappa1) *
            Sin(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) -
        0.28444444444444406 * delta * (0.125 * kappa0 - 0.125 * kappa1) * Sin(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) -
        0.23931433524968299 * delta * (0.040963779567671166 * kappa0 - 0.13654892095090626 * kappa1) *
            Sin(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) -
        0.11846344252809497 * delta * (0.002097327107122293 * kappa0 - 0.042612194596522546 * kappa1) *
            Sin(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ey_2_theta0(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    0.11770584399014787 * delta * Cos(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 +
        0.006395209541267825 * theta1) + 0.20696377469486585 * delta *
        Cos(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.14222222222222203 * delta * Cos(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.03235056055481717 * delta * Cos(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 +
            0.8648197964360765 * theta1) + 0.0007575985379471051 * delta *
        Cos(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ey_2_kappa0(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    0.0050479872655811485 * Power(delta, 2) * Cos(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.03267811424642764 * Power(delta, 2) * Cos(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.03555555555555551 * Power(delta, 2) * Cos(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.009803219676551771 * Power(delta, 2) * Cos(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.0002484565892171975 * Power(delta, 2) * Cos(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ey_2_x0(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    0.0
}

fn grad_ey_2_y0(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    1.0
}

fn grad_ey_2_theta1(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    0.0007575985379471055 * delta * Cos(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.03235056055481716 * delta * Cos(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.14222222222222203 * delta * Cos(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.20696377469486582 * delta * Cos(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.11770584399014787 * delta * Cos(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ey_2_kappa1(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    -0.000248456589217199 * Power(delta, 2) * Cos(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) -
        0.009803219676551771 * Power(delta, 2) * Cos(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) -
        0.03555555555555551 * Power(delta, 2) * Cos(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) -
        0.03267811424642764 * Power(delta, 2) * Cos(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) -
        0.005047987265581148 * Power(delta, 2) * Cos(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

fn grad_ey_2_x1(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    0.0
}

fn grad_ey_2_y1(_theta0: f64, _kappa0: f64, _x0: f64, _y0: f64, _theta1: f64, _kappa1: f64, _x1: f64, _y1: f64, _delta: f64) -> f64 {
    -1.0
}

fn grad_ey_2_delta(theta0: f64, kappa0: f64, _x0: f64, _y0: f64, theta1: f64, kappa1: f64, _x1: f64, _y1: f64, delta: f64) -> f64 {
    0.11846344252809497 * delta * (0.04261219459652255 * kappa0 - 0.002097327107122306 * kappa1) *
        Cos(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.23931433524968299 * delta * (0.13654892095090626 * kappa0 - 0.040963779567671166 * kappa1) *
            Cos(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.28444444444444406 * delta * (0.125 * kappa0 - 0.125 * kappa1) * Cos(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.23931433524968299 * delta * (0.040963779567671166 * kappa0 - 0.13654892095090626 * kappa1) *
            Cos(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.11846344252809497 * delta * (0.002097327107122293 * kappa0 - 0.042612194596522546 * kappa1) *
            Cos(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1) +
        0.11846344252809497 * Sin(0.04261219459652255 * delta * kappa0 - 0.002097327107122306 * delta * kappa1 + 0.9936047904587322 * theta0 + 0.006395209541267825 * theta1) +
        0.23931433524968299 * Sin(0.13654892095090626 * delta * kappa0 - 0.040963779567671166 * delta * kappa1 + 0.8648197964360766 * theta0 + 0.1351802035639234 * theta1) +
        0.28444444444444406 * Sin(0.125 * delta * kappa0 - 0.125 * delta * kappa1 + 0.5 * theta0 + 0.5 * theta1) +
        0.23931433524968299 * Sin(0.040963779567671166 * delta * kappa0 - 0.13654892095090626 * delta * kappa1 + 0.13518020356392346 * theta0 + 0.8648197964360765 * theta1) +
        0.11846344252809497 * Sin(0.002097327107122293 * delta * kappa0 - 0.042612194596522546 * delta * kappa1 + 0.006395209541267821 * theta0 + 0.9936047904587322 * theta1)
}

pub fn cost_function(u: &[f64], size: usize) -> f64 {
    let mut cost = 0.0;
    for i in 0..size {
        let kappa = u[4 * i + 1];
        cost += kappa * kappa;
    }
    let delta_start_index = 4 * size;
    for i in 0..size - 1 {
        let delta = u[delta_start_index + i];
        cost += 0.1 * delta;
    }
    cost
}

pub fn cost_function_grad(u: &[f64], size: usize, grad: &mut [f64]) {
    for i in 0..size {
        let kappa = u[4 * i + 1];
        grad[4 * i + 1] = 2.0 * kappa;
    }
    let delta_start_index = 4 * size;
    for i in 0..size - 1 {
        grad[delta_start_index + i] = 0.1;
    }
}

pub unsafe fn constrain_function(u: &[f64], res: &mut [f64], size: usize) {
    let delta_start_index = 4 * size;
    for i in 0..size - 1 {
        let index0 = i * 4;
        let index1 = index0 + 4;

        let theta0 = u[index0 + 0];
        let kappa0 = u[index0 + 1];
        let x0 = u[index0 + 2];
        let y0 = u[index0 + 3];
        let theta1 = u[index1 + 0];
        let kappa1 = u[index1 + 1];
        let x1 = u[index1 + 2];
        let y1 = u[index1 + 3];
        let delta = u[delta_start_index + i];

        let ex = err_x(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let ey = err_y(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        EX_VEC[i] = ex;
        EY_VEC[i] = ey;

        res[i] = ex.powi(2) + ey.powi(2);
    }
}

pub unsafe fn constrain_function_grad(u: &[f64], d: &[f64], size: usize, res: &mut [f64]) {
    // ex*ex+ey*ey -d-> 2*ex*dex+2*ey*dey
    let delta_start_index = 4 * size;

    for i in 0..size - 1 {
        let index0 = 4 * i;
        let index1 = index0 + 4;

        let theta0 = u[index0 + 0];
        let kappa0 = u[index0 + 1];
        let x0 = u[index0 + 2];
        let y0 = u[index0 + 3];
        let theta1 = u[index1 + 0];
        let kappa1 = u[index1 + 1];
        let x1 = u[index1 + 2];
        let y1 = u[index1 + 3];
        let delta = u[delta_start_index + i];

        let ex = EX_VEC[i];
        let ey = EY_VEC[i];
        let dtheta0 = 2.0 * ex * grad_ex_2_theta0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_theta0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let dkappa0 = 2.0 * ex * grad_ex_2_kappa0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_kappa0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let dx0 = 2.0 * ex * grad_ex_2_x0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_x0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let dy0 = 2.0 * ex * grad_ex_2_y0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_y0(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let dtheta1 = 2.0 * ex * grad_ex_2_theta1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_theta1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let dkappa1 = 2.0 * ex * grad_ex_2_kappa1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_kappa1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let dx1 = 2.0 * ex * grad_ex_2_x1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_x1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let dy1 = 2.0 * ex * grad_ex_2_y1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_y1(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);
        let ddelta = 2.0 * ex * grad_ex_2_delta(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta) +
            2.0 * ey * grad_ey_2_delta(theta0, kappa0, x0, y0, theta1, kappa1, x1, y1, delta);

        // res[i,1] = sum(joc(i,j)*d(j,1)) for j in all possible value
        res[index0 + 0] += dtheta0 * d[i];
        res[index0 + 1] += dkappa0 * d[i];
        res[index0 + 2] += dx0 * d[i];
        res[index0 + 3] += dy0 * d[i];
        res[index1 + 0] += dtheta1 * d[i];
        res[index1 + 1] += dkappa1 * d[i];
        res[index1 + 2] += dx1 * d[i];
        res[index1 + 3] += dy1 * d[i];
        res[delta_start_index + i] += ddelta * d[i];
    }
}
