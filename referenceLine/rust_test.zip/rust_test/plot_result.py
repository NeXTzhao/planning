import math

import matplotlib.pyplot as plt
import csv

xs, ys, ts, ks = [], [], [], []

# with open('/home/pc/CLionProjects/rust_test/target/debug/path_points.csv') as f:
#     csv = csv.reader(f)
#     for cnt, row in enumerate(csv):
#         if cnt == 0:
#             continue;
#         xs.append(float(row[0]))
#         ys.append(float(row[1]))
#
# acc_s = [0]
# for i in range(len(xs)):
#     if i > 0:
#         dx = xs[i] - xs[i - 1]
#         dy = ys[i] - ys[i - 1]
#         acc_s.append(acc_s[-1] + math.hypot(dx, dy))
#
# fig, axs = plt.subplots(1, 2)
# axs[0].plot(xs, ys, 'r', linewidth=0.2)
# axs[1].plot(acc_s, marker='8')
# plt.show()

with open('/home/pc/CLionProjects/rust_test/target/debug/result.csv') as f:
    csv = csv.reader(f)
    for cnt, row in enumerate(csv):
        xs.append(float(row[0]))
        ys.append(float(row[1]))
        ts.append(float(row[2]))
        ks.append(float(row[3]))

fig, axs = plt.subplots(1, 2)
axs[0].plot(xs, ys, '-', marker='h', mfc='none', mec='red')
axs[0].axis('equal')
axs[1].plot(ks, '-')
plt.show()
